export class Dealer {
    id: number=0;
    email: string | any;
    fname: string | any;
    lname: string | any;
    password: string | any;
    dob: Date | any;
    phoneNo:string | any;
    street:string | any;
    city:string | any;
    pincode:string | any;
    
    active: boolean | any;
}
