import { DealerAddress } from './dealer-address';

describe('DealerAddress', () => {
  it('should create an instance', () => {
    expect(new DealerAddress()).toBeTruthy();
  });
});
