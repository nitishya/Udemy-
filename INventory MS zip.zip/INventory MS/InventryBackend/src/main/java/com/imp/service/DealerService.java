package com.imp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imp.model.Dealer;
import com.imp.repository.DealerRepository;
import com.imp.repository.UserRepository;


@Service
@Transactional
public class DealerService {

	
	/*
    @Autowired annotation is used for dependency injection.
	In spring boot application, all loaded beans are eligible 
	for auto wiring to another bean.
	The annotation @Autowired in spring boot is used to 
	auto-wire a bean into another bean.
	*/
	@Autowired
	private DealerRepository drepo;
	
	@Autowired
	private UserRepository urepo;
	
	public void saveDealer(Dealer dealer)
	{
		drepo.save(dealer);		//invokes save() method of JpaRepository
		
	}
	
	public Dealer findByEmail(String email)
	{
		return urepo.findByEmail(email);
	}
}
