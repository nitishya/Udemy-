package com.imp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventryBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventryBackendApplication.class, args);
	}

}
